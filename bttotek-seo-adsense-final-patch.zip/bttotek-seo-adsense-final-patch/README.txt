BTTOTEK SEO + AdSense content patch

This patch covers the 51 production calculator entries: 15 base calculators + 36 spec calculators.

Files:
1. tool-specs.ts - 36 spec calculators, individual SEO title/description/keywords and formula/methodology metadata.
2. tools.ts - combines all 51 tools and generates tool-specific long-form HTML content from each calculator's name, category, keywords, formula and guide. The generated content is intended to be roughly 1000+ words per tool page.
3. tools.$slug.tsx - renders the long-form content, individual SEO metadata, canonical URL, robots, Open Graph, Twitter metadata and FAQ/schema.

Replace the corresponding files in src/lib/ and src/routes/ after taking a backup.

Important: AdSense approval is never guaranteed by code or content alone. Verify live rendering, Search Console indexing, sitemap/robots and ad placement after deployment.
